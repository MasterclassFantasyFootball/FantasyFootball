1. Open Laurence Kelly submission and open Project2.java using any compiler.
2. Build project2.java and a dialog box should appear.
3. Enter a number from 1-3 which each represent a sport.
4. Choose from 1 of the 4 options in the next menu option.
5. Cancel to close the program.
6. Run again if you want to change sport.

Text files must be in same directory as Project2.java
If that is so, Project2.java should have no issues compiling.